import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class Main {

    private static Map<Integer, String> reference;

    static {
        reference = new HashMap<>();
        reference.put(5, "V");
        reference.put(10, "X");
        reference.put(50, "L");
        reference.put(100, "C");
        reference.put(500, "D");
        reference.put(1000, "M");
    }

    public static void main(String[] args) {
        System.out.println(converNumber(6));

    }

    public static String converNumber(int number) {
        var key = reference.get(number) == null ? getKey(number).orElse(0): number;

        System.out.println(key);
        return reference.get(number);
    }

    public static Optional<Integer> getKey(int number) {
        return reference.keySet().stream().map(k -> number - k).filter(r -> r > 0).findFirst();
    }
}