import java.util.*;
import java.util.stream.Collectors;

public class Main {

    private static Map<Integer, String> numberLetter;
    private static Map<Integer, Integer> numberIndex;
    private static Map<Integer, Integer> indexNumber;

    private static Map<String, Integer> letterNumber;

    static {
        numberLetter = new HashMap<>();
        numberLetter.put(1, "I");
        numberLetter.put(5, "V");
        numberLetter.put(10, "X");
        numberLetter.put(50, "L");
        numberLetter.put(100, "C");
        numberLetter.put(500, "D");
        numberLetter.put(1000, "M");

        numberIndex = new HashMap<>();
        numberIndex.put(1, 0);
        numberIndex.put(5, 1);
        numberIndex.put(10, 2);
        numberIndex.put(50, 3);
        numberIndex.put(100, 4);
        numberIndex.put(500, 5);
        numberIndex.put(1000, 6);

        indexNumber = new HashMap<>();
        indexNumber.put(0, 1);
        indexNumber.put(1, 5);
        indexNumber.put(2, 10);
        indexNumber.put(3, 50);
        indexNumber.put(4, 100);
        indexNumber.put(5, 500);
        indexNumber.put(6, 1000);

        letterNumber = new HashMap<>();
        letterNumber.put("I",1);
        letterNumber.put("V",5);
        letterNumber.put("X",10);
        letterNumber.put("L",50);
        letterNumber.put("C",100);
        letterNumber.put("D",500);
        letterNumber.put("M",1000);
    }

    public static void main(String[] args) {
        System.out.println(convertNumber(661));

    }

    public static String convertNumber(int number) {

        Integer previousKey = null;
        Integer auxKey;
        int numberCopy = number;
        List<String> letters = new ArrayList<>();

        while (numberCopy > 0) {
            var key = numberLetter.get(numberCopy) == null ? getKey(numberCopy).orElse(0): numberCopy;

            System.out.println(key);

            int times = division(numberCopy, key);

            if(times <= 3) {

                letters.add(numberLetter.get(key).repeat(times));
                numberCopy = numberCopy - key * times;

            } else {

                auxKey = key;
                if(previousKey == null) {

                    key = indexNumber.get(numberIndex.get(key) + 1);

                } else {
                    key = indexNumber.get(numberIndex.get(previousKey) + 1);

                    if(key - auxKey == previousKey + auxKey * times) {

                        numberCopy = numberCopy + letterNumber.get(letters.get(letters.size() - 1));
                        letters.remove(letters.size() - 1);

                    } else {
                        key = indexNumber.get(numberIndex.get(auxKey) + 1);

                    }
                }

                letters.add(numberLetter.get(auxKey) + numberLetter.get(key));
                numberCopy = numberCopy - (key - auxKey);
            }

            previousKey = key;
        }

        return letters.stream().collect(Collectors.joining());
    }

    public static Optional<Integer> getKey(int number) {
        return numberLetter.keySet().stream().filter(k -> (number / k) > 0).max(Comparator.naturalOrder());
    }

    public static int division(int number, int key) {
        return number / key;
    }

}